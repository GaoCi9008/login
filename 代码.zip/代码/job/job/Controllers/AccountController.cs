﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using job.Data;
using job.Models;
using BCrypt.Net;

namespace job.Controllers
{
    public class AccountController : Controller
    {
        private readonly AppDbContext _context;

        public AccountController(AppDbContext context)
        {
            _context = context;
        }

        [HttpGet]
        public IActionResult Register()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Register(RegisterViewModel model)
        {
            if (ModelState.IsValid)
            {
                bool userExists = await _context.Users.AnyAsync(u => u.Username == model.Username || u.Email == model.Email);
                if (userExists)
                {
                    ModelState.AddModelError("", "用户名或邮箱已被注册");
                    return View(model);
                }

                var user = new User
                {
                    Username = model.Username,
                    Email = model.Email,
                    PasswordHash = BCrypt.Net.BCrypt.HashPassword(model.Password)
                };

                _context.Users.Add(user);
                await _context.SaveChangesAsync();

                return RedirectToAction("Index", "Home");
            }
            return View(model);
        }
    }
}