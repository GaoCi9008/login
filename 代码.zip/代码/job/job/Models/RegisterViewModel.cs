﻿using System.ComponentModel.DataAnnotations;

namespace job.Models
{
    public class RegisterViewModel
    {
        [Required]
        [Display(Name = "用户名")]
        [MaxLength(50)]
        public string Username { get; set; }

        [Required]
        [EmailAddress]
        [Display(Name = "邮箱")]
        public string Email { get; set; }

        [Required]
        [DataType(DataType.Password)]
        [Display(Name = "密码")]
        [MinLength(6, ErrorMessage = "密码至少6位")]
        public string Password { get; set; }

        [DataType(DataType.Password)]
        [Display(Name = "确认密码")]
        [Compare("Password", ErrorMessage = "两次密码不一致")]
        public string ConfirmPassword { get; set; }
    }
}